﻿function DisplayDateTime() {
    var DateTime = new Date();
    var strYear = DateTime.getFullYear();
    var strMonth = DateTime.getMonth() + 1;
    var strDay = DateTime.getDate();
    var strDaysInMonth = new Date(strYear, strMonth, 0).getDate();

    var tagDivD = document.getElementById("DivTagD");
    var tagDivM = document.getElementById("DivTagM");
    var tagDivY = document.getElementById("DivTagY");
    var tagDivDInM = document.getElementById("DivTagDInM");
    var tagDivMVD = document.getElementById("DivTagMVD");
    var tagDivDD = document.getElementById("DivTagDD");
    var tagDivMM = document.getElementById("DivTagMM");
    var tagDivYY = document.getElementById("DivTagYY");
    var tagDivDInMM = document.getElementById("DivTagDInMM");
    var tagDivMVDD = document.getElementById("DivTagMVDD");


    tagDivD.value = strDay;
    tagDivM.value = strMonth;
    tagDivY.value = strYear;
    tagDivDInM.value = strDaysInMonth;
    tagDivMVD.value = strDaysInMonth;
    tagDivDD.value = strDay;
    tagDivMM.value = strMonth;
    tagDivYY.value = strYear;
    tagDivDInMM.value = strDaysInMonth;
    tagDivMVDD.value = strDaysInMonth;
}

function DisplayDateTime2() {
    var DateTime2 = new Date();
    var strrMonth = DateTime2.getMonth() + 1;
    var strrYear = DateTime2.getFullYear();

    var tagDivM2 = document.getElementById("MM");
    var tagDivY2 = document.getElementById("yyyy");

    tagDivM2.value = strrMonth;
    tagDivY2.value = strrYear;
}
///////////////////////////////////////////////////////////
function GeneRevenuWithMadaRevenuReport(url) {
    popupWindow = window.open(url, 'popUpWindow', 'height=350,width=250,left=500,top=250,resizable=no,scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no, status=no')
}


function ContactAdmin(url) {
    popupWindow = window.open(url, 'popUpWindow', 'height=500,width=500,left=500,top=200,resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no, status=no')
}

function Instructions(url) {
    popupWindow = window.open(url, "popUpWindow", "height=500,width=500,left=400,top=120,resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no, status=no")
}

function CloseAll() {
    window.close();
}

function PrintReport(printBtn) {

    var PrintBTN = document.getElementById("printBtn");
    var FooterHidden = document.getElementById("FooterForHiddenId");
    var ReportLogo = document.getElementById("ReportLogoid");
    var PrintVoucherBtn = document.getElementById("printVoucherBtn");
    PrintBTN.style.visibility = "hidden";
    FooterHidden.style.visibility = "Hidden";
    PrintVoucherBtn.style.visibility = "hidden";
    ReportLogo.style.visibility = "visible";
    window.print();
    PrintBTN.style.visibility = "visible";
    FooterHidden.style.visibility = "visible";
    PrintVoucherBtn.style.visibility = "visible";
    ReportLogo.style.visibility = "hidden";
}

function PrintReport2(printBtn) {

    var PrintBTN = document.getElementById("printBtn");
    var FooterHidden = document.getElementById("FooterForHiddenId");
    var ReportLogo = document.getElementById("ReportLogoid");
    PrintBTN.style.visibility = "hidden";
    FooterHidden.style.visibility = "Hidden";
    ReportLogo.style.visibility = "visible";
    window.print();
    PrintBTN.style.visibility = "visible";
    FooterHidden.style.visibility = "visible";
    ReportLogo.style.visibility = "hidden";
}